
export const sizeInPx = (value: number) => {
    return `${value}px`;
};