module.exports = {
    "rules": {
        "quotes": ["warn", "single"]
    }
};