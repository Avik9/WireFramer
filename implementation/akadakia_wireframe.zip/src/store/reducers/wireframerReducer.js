const initState = {
    wireframes: []
};

const wireframerReducer = (state = initState, action) => {
    switch (action.type) {
        /* IF YOU HAVE ANY WIREFRAMER EDITING REDUCERS ADD THEM HERE */ 
        default:
            return state;
    }
};

export default wireframerReducer;